
var number0fDrumButtons = document.querySelectorAll(".drum").length;

for (var i = 0; i<number0fDrumButtons; i++) {
document.querySelectorAll(".drum")[i].addEventListener("click", function()

{
    var buttonInnerHTML= this.innerHTML;
   switch (buttonInnerHTML) {
    case "w":
        var crash1 = new Audio("sounds/crash.mp3");
        crash1.play();

    break;

    case "a":
        var kick = new Audio("sounds/kick-bass.mp3");
        kick.play();

    break;

    case "s":
        var snaree = new Audio("sounds/snare.mp3");
        snaree.play();

    break;

    case "d":
        var tom1 = new Audio("sounds/tom-1.mp3");
        tom1.play();

    break;
    case "j":
        var tomm2 = new Audio("sounds/tom-2.mp3");
        tomm2.play();

    break;

    case "k":
        var tom3 = new Audio("sounds/tom-3.mp3");
        tom3.play();

    break;
    case "l":
        var tom4 = new Audio("sounds/tom-4.mp3");
        tom4.play();

    break;

    default: console.log(buttonInnerHTML);
    
        break;
   }
});
}




//var audio = new Audio("sounds/crash.mp3");
//audio.play();